To import these sample Builder layouts:

- login to wp-admin
- view any post/page frontend
- from the top admin toolbar, select Themify Builder > Import/Export > Import
- upload one of these zip files to import the layout